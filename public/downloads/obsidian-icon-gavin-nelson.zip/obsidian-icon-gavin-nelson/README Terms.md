# Obsidian icon replacement by Gavin Nelson
v1.0

## Terms of Use
This icon is for personal use as an Obsidian.md replacement only and may not be redistributed or modified.

If you have any questions, you can find me on [Twitter](https://twitter.com/Gavmn) or email me at *gavin@nelson.co* 

## Disclaimer
This was not made in collaboration with Obsidian.md and the logo form belongs fully to Obsidian.md

